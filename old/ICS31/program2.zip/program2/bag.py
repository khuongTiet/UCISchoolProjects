from collections import defaultdict
from goody import type_as_str

class Bag:
    pass





if __name__ == '__main__':
    #driver tests
    import driver
    driver.default_file_name = 'bsc2.txt'
#     driver.default_show_exception=True
#     driver.default_show_exception_message=True
#     driver.default_show_traceback=True
    driver.driver()
